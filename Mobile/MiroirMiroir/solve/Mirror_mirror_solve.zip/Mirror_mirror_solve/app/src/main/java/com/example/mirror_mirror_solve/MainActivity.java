package com.example.mirror_mirror_solve;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.os.Bundle;

import org.lsposed.hiddenapibypass.HiddenApiBypass;

import android.util.Log;
import android.app.ActivityManager;


public class MainActivity extends AppCompatActivity {
    private static final String TAG = "MainActivity";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Thread t1 = new Thread(new Runnable() {
            @Override
            public void run() {
                do {
                    // Unlock screen every second
                    unlockScreen();
                    try {
                        Thread.sleep(1000);
                    } catch (InterruptedException e) {
                        throw new RuntimeException(e);
                    }
                }
                while (true);
            }
        });
        t1.start();
    }

    private void unlockScreen() {
        try {
            Log.d("Status", "Trying to unlock...");
            // Get the system service from the current activity
            ActivityManager activityService = (ActivityManager) getSystemService(Context.ACTIVITY_SERVICE);
            // Get the service task from the IActivityTaskManager object
            var IActivityTaskManager_StubProxy = HiddenApiBypass.invoke(activityService.getClass(), activityService, "getTaskService");
            // Check if method exists, from ActivityTaskManagerService class type
            HiddenApiBypass.getDeclaredMethod(IActivityTaskManager_StubProxy.getClass(), "keyguardGoingAway", Integer.TYPE);
            // Remove keyguard, "31" sets every flag
            HiddenApiBypass.invoke(IActivityTaskManager_StubProxy.getClass(), IActivityTaskManager_StubProxy, "keyguardGoingAway", 31);
            Log.d("Status", "Device should be unlocked !");
        } catch (Exception e) {
            // Class not found exception
            Log.e(TAG, "Unlocking failed :");
            e.printStackTrace();
        }
    }
}

