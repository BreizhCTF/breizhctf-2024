from pathlib import Path

WEBSITE_ADDRESS = "twdz7fwj9qvbknhyemkq6vvg62m7ghpbe6gzo6bb0m2akw5xrhnydeuj.notanonion"
ROOT_PATH = Path(__file__).parent
MAX_UPLOAD_FILE_SIZE = 104_857_600
SOCKET_TIMEOUT = 10
