import socket
import threading
from ascii_banner import welcome_banner
from db_utils import wsql
from datetime import datetime
import re
from file_utils import retrieve_file_from_link, store_user_file
from constants import MAX_UPLOAD_FILE_SIZE, SOCKET_TIMEOUT
import tempfile
from hashlib import sha256
from viztracer import ignore_function


class SocketClient:
    def __init__(self, client_socket: socket.socket) -> None:
        self.sock = client_socket
        self.sock.settimeout(SOCKET_TIMEOUT)
        self.db_conn = wsql()
        self.handle_client()

    def __del__(self):
        """Automatically close connection when object is destroyed"""
        try:
            self.sock.close()
        except:
            pass

    def send_error(self, msg: str):
        self.sock.sendall(f"/!\\ {msg}\n".encode())

    @ignore_function
    def send_info(self, msg: str):
        self.sock.sendall(f"# {msg}\n".encode())

    @ignore_function
    def send_ask(self, msg: str):
        self.sock.sendall(f"$ {msg}\n".encode())

    @ignore_function
    def recv_wrapper(self, size: int = 1024, decode: bool = True):
        r = self.sock.recv(size)
        if decode:
            r = r.strip().decode()
        return r

    @ignore_function
    def recv_file(self, size: int):
        to_receive = size
        self.sock.settimeout(3)
        valid_reception = False
        with tempfile.TemporaryFile() as f:
            try:
                while to_receive:
                    buffer_size = 1024 if to_receive >= 1024 else to_receive
                    data_chunk = self.sock.recv(buffer_size)
                    f.write(data_chunk)
                    to_receive -= len(data_chunk)
                f.seek(0)
                received_data = f.read()
                valid_reception = True
            except socket.timeout:
                self.send_error(
                    f"Missing {to_receive} bytes out of {size} announced bytes."
                )

        f.close()
        self.sock.settimeout(SOCKET_TIMEOUT)
        return received_data if valid_reception else False

    def regex_check_token(self, token: str):
        regex = r"^[0-9a-f]{1,64}$|^\$[0-9a-f_]{32}\$"  # Handle previous token format for now
        if not re.match(regex, token):
            self.send_error(f"Invalid token.")
            return False
        else:
            return True

    def authenticate(self):
        _now = datetime.now()
        self.send_ask(f"Enter your token :")
        _token = self.recv_wrapper()
        if not self.regex_check_token(_token):
            return False
        self.token = _token
        user = self.db_conn.select_one(
            "SELECT token, expire_time FROM tokens WHERE token='%s'", (self.token,)
        )
        if user:
            if user[1] < _now:
                self.send_error(f"Token expired. Please request a new one.")
                return False
            else:
                self.send_info(f'Authentication with token "{self.token}" successful !')
                return True
        else:
            self.send_error(f"Invalid token.")
            return False

    def download(self):
        self.send_ask("Please provide a share link :")
        link = self.recv_wrapper()
        try:
            data = retrieve_file_from_link(link)
        except Exception as e:
            self.send_error("Invalid share link.")
            return None
        self.send_info(
            f"Link is valid ! Sending {len(data)} raw bytes to you, with SHA256[{sha256(data).hexdigest()}]. File will be deleted instantly after the send, successful or not :"
        )
        self.sock.sendall(data)
        self.sock.sendall(b"\n")
        return None

    def upload(self):
        self.send_ask(f"Indicate the exact file size :")
        file_size = self.recv_wrapper()
        # Verify provided file size
        assert_check = False
        try:
            assert_check = eval(f"0 < int({file_size}) <= {MAX_UPLOAD_FILE_SIZE}")
        except Exception as e:
            self.send_error(
                f"Inadequate file size. Please ensure you specified an integer."
            )
            return None
        if not assert_check:
            self.send_error(
                f"File size exceeds the {MAX_UPLOAD_FILE_SIZE} bytes limit, or is invalid. Upload denied."
            )
            return None
        file_size = int(file_size)
        # Checksum
        self.send_ask(f"Send SHA256 of data :")
        checksum = self.recv_wrapper()
        # Get raw content
        self.sock.sendall(b"$ Please send your file, as a raw stream :")
        received_data = self.recv_file(file_size)
        if received_data == False:
            return None
        # Checksum comparison
        if sha256(received_data).hexdigest() != checksum:
            self.send_error(
                f"Wrong checksum between announced and uploaded data. Aborting..."
            )
            return None
        # Storage
        link = store_user_file(received_data)
        self.send_info(f"Share link : {link}")

    def handle_client(self):
        self.sock.sendall(welcome_banner)
        while True:
            try:
                self.send_ask(
                    f"Make a choice :\n1 : Download a file\n2 : Upload a file"
                )
                choice = self.recv_wrapper()
                if choice == "1":
                    self.download()
                elif choice == "2":
                    if self.authenticate():
                        self.upload()
                else:
                    self.send_error(f"Invalid choice")
                # Separate sessions
                self.sock.sendall(f"{'='*5}\n".encode())
            except BrokenPipeError:
                pass
            except socket.timeout:
                try:
                    self.send_error("Timeout. Closing connection...")
                except:
                    pass
                break
            except Exception:
                break


def main():
    host = "0.0.0.0"
    port = 3535

    server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    server_socket.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    server_socket.bind((host, port))

    server_socket.listen(5)
    print(f"[*] Listening on {host}:{port}")

    try:
        while True:
            client_socket, addr = server_socket.accept()
            print(f"[*] Accepted connection from {addr[0]}:{addr[1]}")
            client_handler_thread = threading.Thread(
                target=SocketClient, args=(client_socket,)
            )
            client_handler_thread.start()
    except KeyboardInterrupt:
        print("[*] Server shutting down")
        server_socket.close()
    except Exception as e:
        print("[*] Server shutting down")
        server_socket.close()


if __name__ == "__main__":
    main()
