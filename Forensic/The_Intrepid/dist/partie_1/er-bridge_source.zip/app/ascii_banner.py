from constants import WEBSITE_ADDRESS

WIDTH = 49
NEWLINE = "\n"
ANSI_RED = "\x1B[31m"
ANSI_GREEN = "\x1B[32m"
ANSI_CYAN = "\x1B[36m"
ANSI_RESET = "\x1B[0m"
ANSI_BOLD = "\x1B[1m"


def helper(to_insert: str, target_length: int = WIDTH):
    """Put text in the middle of a given length. Split lines if needed."""
    if len(to_insert) <= target_length:
        s_index = (target_length // 2) - (len(to_insert) // 2)
        f_str = " " * (s_index - 1) + to_insert
        f_str += " " * (target_length - len(f_str))
        return f_str
    else:
        to_ret = []
        for chunk in [
            to_insert[i : i + target_length]
            for i in range(0, len(to_insert), target_length)
        ]:
            to_ret.append(helper(chunk))
        return "\n".join(to_ret)


welcome_banner_ascii = f"""
{ANSI_RED}
       ________________________________         
      /                                "-_          
     /      .  |  .                       \\          
    /      : \\ | / :{ANSI_GREEN}{helper('er-bridge', 23)}{ANSI_RED}\\         
   /        '-___-'                         \\      
  /_________________________________________ \\      
       _______| |________________________--""-L 
      /       | |                              \\ 
     /       /   \\{ANSI_GREEN}{helper('secure & anonymous', 30)}{ANSI_RED}|
    /      :'     ':                            |
   /        '-___-'{ANSI_GREEN}{helper('file sharing', 28)}{ANSI_RED}/ 
  /_________________________________________--"
{ANSI_RESET}""".encode()

welcome_banner_text = f"""
{'#'*WIDTH}
{helper('Grab your access token at :')}
{ANSI_CYAN}{helper(f'{WEBSITE_ADDRESS}/purchase')}{ANSI_RESET}
Price : 0,002 ETH for 3 months of unlimited access
{'#'*WIDTH}

""".encode()
welcome_banner = welcome_banner_ascii + welcome_banner_text
