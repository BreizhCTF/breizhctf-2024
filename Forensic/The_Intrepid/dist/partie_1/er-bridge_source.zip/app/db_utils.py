import mysql.connector
import os
from pathlib import Path
from dotenv import load_dotenv
from viztracer import ignore_function

load_dotenv(Path(__file__).parent / ".env")


class wsql:
    """Wrapper for SQL database interactions"""

    @ignore_function
    def __init__(self):
        params = {
            "host": os.getenv("MYSQL_HOST"),
            "port": os.getenv("MYSQL_PORT"),
            "database": os.getenv("MYSQL_DATABASE"),
            "user": os.getenv(f"MYSQL_USER"),
            "password": os.getenv(f"MYSQL_PASSWORD"),
        }

        self.conn = mysql.connector.connect(**params)

    def __del__(self):
        try:
            self.conn.close()
        except:
            pass

    def commit(self, query: str, values: tuple = ()) -> int:
        """Wrapper for commit actions (INSERT, UPDATE ...)"""

        cursor = self.conn.cursor()
        cursor.execute(query, values)
        self.conn.commit()
        rows = cursor.rowcount
        cursor.close()

        return rows

    def select_one(self, query: str, values: tuple = (), dict=False):
        """Wrapper for fetchone()"""

        cursor = self.conn.cursor(dictionary=dict)
        cursor.execute(query % values)
        res = cursor.fetchone()
        cursor.close()

        return res

    def select_all(self, query: str, values: tuple = (), dict=False):
        """Wrapper for fetchall()"""

        cursor = self.conn.cursor(dictionary=dict)
        cursor.execute(query, values)
        res = cursor.fetchall()
        cursor.close()

        return res
