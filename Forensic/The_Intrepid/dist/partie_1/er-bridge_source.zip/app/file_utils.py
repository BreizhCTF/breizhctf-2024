from cryptography.hazmat.primitives import hashes, hmac
from cryptography.hazmat.backends import default_backend
from Crypto.Cipher import AES
from constants import ROOT_PATH
import re
from pathlib import Path

# safe, based on os.urandom
import secrets


STORAGE_PATH = ROOT_PATH / "uploads"
FILENAME_LEN = 20
AES_KEY_SIZE = 32
AES_IV_SIZE = 16
HMAC_SIGNATURE_SIZE = 12

FILENAME_LEN_HEX = FILENAME_LEN * 2
AES_KEY_SIZE_HEX = AES_KEY_SIZE * 2
AES_IV_SIZE_HEX = AES_IV_SIZE * 2
HMAC_SIGNATURE_SIZE_HEX = HMAC_SIGNATURE_SIZE * 2

STORAGE_PATH.mkdir(exist_ok=True)


def store_user_file(data: bytes):
    for _ in range(3):
        filename = dir_name = secrets.token_hex(FILENAME_LEN)
        if not Path(STORAGE_PATH / dir_name).exists():
            break
    else:
        raise Exception("Cannot generate link")

    key = secrets.token_bytes(AES_KEY_SIZE)
    iv = secrets.token_bytes(AES_IV_SIZE)
    encrypted, _ = encrypt_text(key, data, iv)
    link_digest = hmac_text(key, f"{filename}{iv.hex()}".encode())
    link = f"{filename}#{key.hex()}{iv.hex()}{link_digest}"
    Path(STORAGE_PATH / dir_name).mkdir()
    with open(STORAGE_PATH / dir_name / filename, "wb+") as f:
        f.write(encrypted)

    return link


def retrieve_file_from_link(link: str):
    filename, key, iv = verify_link(link)
    dir_name = filename
    file_path = Path(STORAGE_PATH / dir_name / filename)
    if not file_path.exists():
        raise Exception("File does not exist anymore")

    with open(file_path, "rb") as f:
        encrypted = f.read()

    decrypted = decrypt_text(key, iv, encrypted)
    file_path.unlink()
    Path(STORAGE_PATH / dir_name).rmdir()
    return decrypted


def verify_link(link: str):
    filename, key, iv, digest = re.findall(
        f"^([a-f0-9]{{{FILENAME_LEN_HEX}}})#([a-f0-9]{{{AES_KEY_SIZE_HEX}}})([a-f0-9]{{{AES_IV_SIZE_HEX}}})([a-f0-9]{{{HMAC_SIGNATURE_SIZE_HEX}}})$",
        link,
    )[0]
    key, iv = bytes.fromhex(key), bytes.fromhex(iv)
    check_digest = hmac_text(key, f"{filename}{iv.hex()}".encode())
    if secrets.compare_digest(digest, check_digest):
        return filename, key, iv
    else:
        raise Exception("Invalid link")


def hmac_text(key: bytes, text: bytes):
    h = hmac.HMAC(key, hashes.SHA256(), backend=default_backend())
    h.update(text)
    return h.finalize()[:HMAC_SIGNATURE_SIZE].hex()


def encrypt_text(key: bytes, cleartext: bytes, iv: bytes = None):
    iv = secrets.token_bytes(AES_IV_SIZE) if iv != None else iv
    # https://github.com/Legrandin/pycryptodome/issues/353
    cipher = AES.new(key, AES.MODE_CTR, initial_value=iv, nonce=b"")
    ciphertext = cipher.encrypt(cleartext)
    return ciphertext, iv


def decrypt_text(key: bytes, iv: bytes, ciphertext: bytes):
    cipher = AES.new(key, AES.MODE_CTR, initial_value=iv, nonce=b"")
    cleartext = cipher.decrypt(ciphertext)
    return cleartext
