**De :** `the-intrepid-journal@notproton.me`  
**À :** `dfir-independant-consulting@notproton.me` (vous)

**Objet :** Re : Re : Re : [`www.dfir-independant-consulting.notcom`] Nouveau contrat : The Intrepid journal

> J'ai entièrement identifié le chemin d'attaque, perpétré par l'attaquant. J'ai été capable de déchiffrer le fichier indiqué dans votre précédent mail. L'attaquant était en mesure de prédire les identifiants de partage, en très peu d'essais. Je vous fait suivre les contre-mesures à appliquer, dans le prochain mail. 

The Intrepid vous remercie grandement pour vos investigations, et nous attendons vos contre-mesures. Acceptez-vous les ETH, pour le paiement ?


---

**De :** `anonymous-reporter@notproton.me`  
**À :** `dfir-independant-consulting@notproton.me` (vous)

**Objet :** Re : The Intrepid journal is corrupted at its root

> You told the truth. I was able to get my hand on a dirty contract. Unfortunately, it was mostly censured. 
> PS : My work ethic cannot let your backdoor in place.

._.
