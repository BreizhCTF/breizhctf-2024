**De :** `the-intrepid-journal@notproton.me`  
**À :** `dfir-independant-consulting@notproton.me` (vous)

**Objet :** Re : Re : Re : [`www.dfir-independant-consulting.notcom`] Nouveau contrat : The Intrepid journal

> J'ai entièrement identifié le chemin d'attaque, perpétré par l'attaquant. J'ai été capable de déchiffrer le fichier indiqué dans votre précédent mail. L'attaquant était en mesure de prédire les identifiants de partage, en très peu d'essais. Je vous fait suivre les contre-mesures à appliquer, dans le prochain mail. 
> 
> PS : L'attaquant a tenté de m'approcher, afin de me ralentir dans mon investigation, en vous faisant passer pour une association journalistique corrompue. Heureusement, il n'est pas facile de me détourner de mon travail !

The Intrepid vous remercie grandement pour vos investigations, et attendons vos contre-mesures. Le paiement convenu est bien de **2.12046** ETH ?


