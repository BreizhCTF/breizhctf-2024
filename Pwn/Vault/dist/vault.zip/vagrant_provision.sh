apt-get update
apt install patchelf