  <!-- Footer -->
  <footer class="bg-dark text-white text-center py-3 mt-auto">
    <p>Copyright @MyCMS 2024</p>
  </footer>
</body>
</html>
